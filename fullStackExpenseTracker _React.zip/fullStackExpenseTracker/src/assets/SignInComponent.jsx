import React, { useState } from 'react';
import { Button, Form, Container, Row, Col } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';

function SignInComponent() {
  const [credentials, setCredentials] = useState({
    email: '',
    password: ''
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/login', credentials);
      toast.success("Sign-in successful!");
      navigate("/"); 
    } catch (error) {
      toast.error("Invalid email or password");
      console.error("Login error:", error);
    }
  };

  return (
    <div className="bg-dark text-light d-flex justify-content-center align-items-center" style={{ minHeight: "100vh" }}>
      <Container>
        <Row className="justify-content-center">
          <Col xs={12} sm={8} md={6} lg={4}>
            <Form className="p-4 shadow-lg bg-secondary rounded" onSubmit={handleSubmit}>
              <h1 className="text-warning text-center fw-bold mb-4">SIGN-IN</h1>

              <Form.Group className="form-floating mb-3" controlId="formEmail">
                <Form.Control
                  type="email"
                  placeholder="name@example.com"
                  name="email"
                  value={credentials.email}
                  onChange={handleChange}
                  className="bg-dark text-light border-info border-3"
                  required
                />
                <Form.Label className="text-light">Email address</Form.Label>
              </Form.Group>

              <Form.Group className="form-floating mb-4" controlId="formPassword">
                <Form.Control
                  type="password"
                  placeholder="Password"
                  name="password"
                  value={credentials.password}
                  onChange={handleChange}
                  className="bg-dark text-light border-info border-3"
                  required
                />
                <Form.Label className="text-light">Password</Form.Label>
              </Form.Group>

              <div className="d-flex justify-content-between">
                <Button type="submit" variant="outline-info" className="fw-bold text-light border-3 px-4">
                  SIGN-IN
                </Button>
                <Link to="/sign-Up">
                  <Button variant="outline-warning" className="fw-bold text-light border-3 px-4">
                    SIGN-UP
                  </Button>
                </Link>
              </div>
            </Form>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default SignInComponent;
