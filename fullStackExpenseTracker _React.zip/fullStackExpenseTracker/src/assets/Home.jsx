import React, { useState, useEffect } from 'react';
import { Container, Form, Row, Col, Table, Button } from 'react-bootstrap';
import axios from 'axios';

function Home() {
    const [formData, setFormData] = useState({
        category: '',
        amount: '',
        comment: '',
        date: ''
    });
    const [expenses, setExpenses] = useState([]);
    const [editId, setEditId] = useState(null);

    useEffect(() => {
        fetchExpenses();
    }, []);

    const fetchExpenses = () => {
        axios.get("http://localhost:8080/expenses")
            .then(res => setExpenses(res.data))
            .catch(err => console.error("Error fetching expenses:", err));
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formData.category || !formData.amount || !formData.date) {
            alert("Please fill in category, amount, and date");
            return;
        }

        try {
            if (editId) {

                const response = await axios.put(`http://localhost:8080/expenses/${editId}`, formData);
                const updatedExpense = response.data;

                setExpenses(prev =>
                    prev.map(exp => exp.id === editId ? updatedExpense : exp)
                );
            } else {

                const response = await axios.post("http://localhost:8080/expenses", formData);
                setExpenses(prev => [response.data, ...prev]);

            }

            setFormData({ category: '', amount: '', comment: '', date: '' });
            setEditId(null);
        } catch (error) {
            console.error(error);
        }
    };


    const handleEdit = (expense) => {
        setFormData({
            category: expense.category,
            amount: expense.amount,
            comment: expense.comment,
            date: expense.date

            
        });
        setEditId(expense.id);
    };


    const handleDelete = async (id) => {
        try {
            await axios.delete(`http://localhost:8080/delete/${id}`);

        } catch (error) {
            console.error("Error deleting expense:", error);
        }
    };

    return (
        <Container fluid className="bg-dark text-light pt-4 pb-5" style={{ minHeight: "100vh" }}>
            <h1 className="text-warning text-center mt-3 mb-4">Add Your Expenses here !!</h1>

            <Form className="px-3 px-md-5" onSubmit={handleSubmit}>
                <Row className="g-3 justify-content-center">
                    <Col xs={12} sm={6} md={3}>
                        <Form.Control name="category" value={formData.category} onChange={handleChange} placeholder="Expense Category" required />
                    </Col>
                    <Col xs={12} sm={6} md={2}>
                        <Form.Control name="amount" type="number" value={formData.amount} onChange={handleChange} placeholder="Amount" required />
                    </Col>
                    <Col xs={12} sm={6} md={3}>
                        <Form.Control name="comment" value={formData.comment} onChange={handleChange} placeholder="Comment" />
                    </Col>
                    <Col xs={12} sm={6} md={2}>
                        <Form.Control name="date" type="date" value={formData.date} onChange={handleChange} required />
                    </Col>
                    <Col xs={12} md="auto">
                        <Button type="submit" variant="outline-warning" className="fw-bold text-light border-3 px-4">
                            {editId ? "Update Expense" : "Add Expense"}
                        </Button>
                    </Col>
                </Row>
            </Form>

            {expenses.length > 0 && (
                <Container fluid className="mt-5 px-3 px-md-5 text-info font-monospace">
                    <h3 className="text-center mb-4">Expenses List</h3>
                    <Table striped bordered hover variant="dark" responsive className="rounded shadow-sm">
                        <thead className="bg-danger text-center text-light">
                            <tr>
                                <th>Expences</th>
                                <th>Expense Name</th>
                                <th>Amount</th>
                                <th>Comment</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {expenses.map((expense, index) => (
                                <tr key={expense.id} className="text-center align-middle">
                                    <td>{index + 1}</td>
                                    <td>{expense.category}</td>
                                    <td>₹ {expense.amount}</td>
                                    <td>{expense.comment}</td>
                                    <td>{expense.date}</td>
                                    <td>
                                        <div className="d-flex justify-content-center gap-2">
                                            <Button size="sm" variant="outline-info" onClick={() => handleEdit(expense)}>Edit</Button>
                                            <Button size="sm" variant="outline-danger" onClick={() => handleDelete(expense.id)}>Delete</Button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </Container>
            )}
        </Container>
    );
}

export default Home;
