import axios from 'axios';
import React, { useState } from 'react';
import { Button, Form, Container, Row, Col } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

function SignUpComponent() {

    
    const [user, setUser] = useState({
        name: "",
        email: "",
        password: ""
    });

    const navigate = useNavigate();

    const onInputChange = (e) => {
        setUser({
            ...user,
            [e.target.name]: e.target.value
        });
    };

    const onSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:8080/user-sign-in", user, {
                headers: {
                    "Content-Type": "application/json"
                }
            });
            toast.success("Sign-up successful!");
            console.log("Response:", response.data);
            navigate("/");
        } catch (error) {
            console.error("Submission error:", error.message);
            toast.error("Sign-up failed!");
        }
    };

    return (
        <div
            className="bg-dark text-light d-flex justify-content-center align-items-center"
            style={{
                minHeight: "100vh",
                backgroundSize: "cover",
                backgroundPosition: "center",
            }}
        >
            <Container>
                <Row className="justify-content-center">
                    <Col xs={12} sm={10} md={8} lg={6} xl={5}>
                        <Form className="bg-secondary p-4 rounded shadow-lg" onSubmit={onSubmit}>
                            <h1 className="text-warning text-center mb-4">SIGN-UP</h1>

                            <Form.Group controlId="formName" className="form-floating mb-4">
                                <Form.Control
                                    type="text"
                                    placeholder="Enter name"
                                    name="name"
                                    value={user.name}
                                    onChange={onInputChange}
                                    className="bg-dark text-light border-info border-3"
                                    required
                                />
                                <Form.Label className="text-light">User  Name</Form.Label>
                            </Form.Group>

                            <Form.Group controlId="formEmail" className="form-floating mb-4">
                                <Form.Control
                                    type="email"
                                    placeholder="name@example.com"
                                    name="email"
                                    value={user.email}
                                    onChange={onInputChange}
                                    className="bg-dark text-light border-info border-3"
                                    required
                                />
                                <Form.Label className="text-light">Email address</Form.Label>
                            </Form.Group>

                            <Form.Group controlId="formPassword" className="form-floating mb-4">
                                <Form.Control
                                    type="password"
                                    placeholder="Password"
                                    name="password"
                                    value={user.password}
                                    onChange={onInputChange}
                                    className="bg-dark text-light border-info border-3"
                                    required
                                />
                                <Form.Label className="text-light">Password</Form.Label>
                            </Form.Group>

                            <div className="d-flex justify-content-between">
                                <Button
                                    type="submit"
                                    variant="outline-warning"
                                    className="fw-bold text-light border-3 px-4"
                                >
                                    SIGN-UP
                                </Button>
                                <Link to="/sign-In">
                                    <Button
                                        variant="outline-info"
                                        className="fw-bold text-light border-3 px-4"
                                    >
                                        SIGN-IN
                                    </Button>
                                </Link>
                            </div>
                        </Form>
                    </Col>
                </Row>
            </Container>
        </div>
    );
}

export default SignUpComponent;
