import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Offcanvas from 'react-bootstrap/Offcanvas';
import React from 'react';
import { Link } from 'react-router-dom';

function NavBarComponent() {
    return (
        <>
            <Container fluid className='p-0'>
                <Navbar expand="lg" className="bg-secondary shadow sticky-top w-100" variant="dark">
                    <Container>
                        <Navbar.Brand>
                            <Link to="/" className='text-decoration-none text-light fs-2 fw-bold'>Expense Tracker</Link>
                        </Navbar.Brand>
                        <Navbar.Toggle aria-controls="offcanvasNavbar" />
                        <Navbar.Offcanvas
                            id="offcanvasNavbar"
                            aria-labelledby="offcanvasNavbarLabel"
                            placement="end"
                            className="bg-secondary"
                        >
                            <Offcanvas.Header closeButton>
                                <Offcanvas.Title id="offcanvasNavbarLabel">
                                    <Link to="/" className='text-decoration-none text-light fw-bold'>Expense Tracker</Link>
                                </Offcanvas.Title>
                            </Offcanvas.Header>
                            <Offcanvas.Body>
                                <Nav className="ms-auto d-flex flex-column flex-lg-row align-items-lg-center">
                                    <Link to="/sign-In" className='mb-2 mb-lg-0'>
                                        <button className='btn border-3 btn-outline-info text-light me-lg-3'>Sign-In</button>
                                    </Link>
                                    <Link to="/sign-Up" className='mb-2 mb-lg-0'>
                                        <button className='btn border-3 btn-outline-warning text-light me-lg-3'>Sign-Up</button>
                                    </Link>
                                    <Link to="/pie-chart">
                                        <button className='btn border-3 btn-outline-danger text-light'>Track Expense</button>
                                    </Link>
                                </Nav>
                            </Offcanvas.Body>
                        </Navbar.Offcanvas>
                    </Container>
                </Navbar>
            </Container>
        </>
    )
}

export default NavBarComponent;
