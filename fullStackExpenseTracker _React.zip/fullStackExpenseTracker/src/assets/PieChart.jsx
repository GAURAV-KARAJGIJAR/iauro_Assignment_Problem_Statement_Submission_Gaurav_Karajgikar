import React from 'react'
// import { Container } from 'react-bootstrap';
// import { Pie } from 'react-chartjs-2';

function PieChart() {
    return (
        <>
<h1>pie</h1>
        </>
    )
}

export default PieChart