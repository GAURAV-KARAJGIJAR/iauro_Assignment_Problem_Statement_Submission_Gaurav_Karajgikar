import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, BrowserRouter, Routes } from 'react-router-dom';
// import HomeComponent from './assets/HomeComponent';
import SignUpComponent from './assets/SignUpComponent';
import SignInComponent from './assets/SignInComponent';
import NavBarComponent from './assets/NavBarComponent';
import Home from './assets/Home';
import PieChart from './assets/PieChart';

function App() {

  return (
    <>
      <BrowserRouter>
        <NavBarComponent/>
        <Routes>
          <Route path='/' element={<Home/>} ></Route>
          <Route path='/sign-Up' element={<SignUpComponent/>}> </Route>
          <Route path='/sign-In' element={<SignInComponent/>}> </Route>
          <Route path='/pie-chart' element={<PieChart/>}> </Route>
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
