package com.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.main.beans.ExpencesAddRequest;
import com.main.beans.ExpencesAddResponce;
import com.main.service.ExpencessService;

@RestController
@CrossOrigin("http://localhost:5173/")
public class ExpencesController {

	@Autowired
	private ExpencessService expencessService;

	@PostMapping("/expenses")
	public ExpencesAddResponce viewData(@RequestBody ExpencesAddRequest expencesAddRequest) {

		ExpencesAddResponce expencesAddResponce = expencessService.viewData(expencesAddRequest);

		return expencesAddResponce;
	}

//=========================	POST Mapping for login ====================

	@GetMapping("/expenses")
	public List<ExpencesAddResponce> fetchData() {

		List<ExpencesAddResponce> expencesAddResponces = expencessService.fetchData();

		return expencesAddResponces;

	}

//=====================	delete mapping =================

	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable int id) {
		expencessService.delete(id);
		return "Data has been deleted";
	}

//========================= update ==================

	@PutMapping("/update-data")
	public ExpencesAddResponce updateData(@RequestParam int id, @RequestBody ExpencesAddRequest expencesAddRequest) {

		ExpencesAddResponce expencesAddResponce = expencessService.updateData(id, expencesAddRequest);

		return expencesAddResponce;

	}

}
