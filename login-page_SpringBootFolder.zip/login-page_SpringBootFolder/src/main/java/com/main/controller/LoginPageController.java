package com.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.main.beans.ExpencesAddRequest;
import com.main.beans.LoginPageRequest;
import com.main.beans.LoginPageResponse;
import com.main.service.LoginPageService;

@RestController
@CrossOrigin("http://localhost:5173/")
public class LoginPageController {

	@Autowired
	private LoginPageService loginPageService;

// ------------------------------------- POST CALL -----------------------------------

	@PostMapping("/user-sign-in")
	public LoginPageResponse EnterLoginDetails(@RequestBody LoginPageRequest loginPageRequest) {

		LoginPageResponse loginPageResponse = loginPageService.EnterLoginDetails(loginPageRequest);

		return loginPageResponse;
	}

// -------------------------------------- GET ALL CALL -------------------------------------

	@GetMapping("/fetch-your-details")
	public List<LoginPageResponse> fetchDetails() {

		List<LoginPageResponse> loginPageResponse = loginPageService.fetchDetails();

		return loginPageResponse;
	}

// -------------------------------------- GET ID CALL -------------------------------------

//	@GetMapping("/fetch-your-details-by-id")
//	public LoginPageResponse fetchDetailByID(@RequestParam int id) {
//
//		LoginPageResponse loginPageResponse = loginPageService.fetchDetailByID(id);
//
//		return loginPageResponse;
//	}
	
// ------------------------------------ UPDATE CALL ---------------------------------------
	
	@PutMapping("/update-details")
	public LoginPageResponse updateDetails(@RequestBody LoginPageRequest loginPageRequest, @RequestParam int id) {
		
		LoginPageResponse loginPageResponse = loginPageService.updateDetails(loginPageRequest,id);
		
		return loginPageResponse;
	}
	
// ------------------------------------ DELETE CALL ---------------------------------------
	
	@DeleteMapping("/delete-details")
	public String deleteDetails(@RequestParam int id) {
		
	loginPageService.deleteDetails(id);
		
		return "your details has been removed successfully !!!!!!!";
	}
	
	// login page ============================

	@PostMapping("/login")
	public String loginAccess(@RequestBody LoginPageRequest loginPageRequest) {

		loginPageService.loginAccess(loginPageRequest);

		return "login acessed";
		
	}

}

