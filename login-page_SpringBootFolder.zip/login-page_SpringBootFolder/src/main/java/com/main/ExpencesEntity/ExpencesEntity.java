package com.main.ExpencesEntity;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "ExpencesEntity")
public class ExpencesEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int ID;
	
	private String category;

	private Double amount;

	private String comment;

	private String date;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "ExpencesEntity [category=" + category + ", amount=" + amount + ", comment=" + comment + ", date=" + date
				+ "]";
	}

	public ExpencesEntity(String category, Double amount, String comment, String date) {
		super();
		this.category = category;
		this.amount = amount;
		this.comment = comment;
		this.date = date;
	}

	public ExpencesEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

}
