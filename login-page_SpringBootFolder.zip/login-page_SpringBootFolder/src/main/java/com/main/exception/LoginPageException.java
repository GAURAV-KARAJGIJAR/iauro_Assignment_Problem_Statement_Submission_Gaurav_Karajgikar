package com.main.exception;

import org.springframework.http.HttpStatus;

public class LoginPageException extends RuntimeException {
	
	private HttpStatus errorCode;
	
	private String errorMessage;

	public HttpStatus getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(HttpStatus errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public LoginPageException(HttpStatus errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public LoginPageException() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "LoginPageException [errorCode=" + errorCode + ", errorMessage=" + errorMessage + "]";
	}
	
	
}
