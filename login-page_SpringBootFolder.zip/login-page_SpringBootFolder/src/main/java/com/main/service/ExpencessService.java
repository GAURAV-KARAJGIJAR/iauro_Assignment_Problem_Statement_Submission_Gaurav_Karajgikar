package com.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.ExpencesEntity.ExpencesEntity;
import com.main.beans.ExpencesAddRequest;
import com.main.beans.ExpencesAddResponce;
import com.main.repository.ExpencesRepository;

@Service
public class ExpencessService {

	@Autowired
	private ExpencesRepository expencesRepository;

	public ExpencesAddResponce viewData(ExpencesAddRequest expencesAddRequest) {

		ExpencesEntity expencesEntity = new ExpencesEntity();

		expencesEntity.setCategory(expencesAddRequest.getCategory());
		expencesEntity.setAmount(expencesAddRequest.getAmount());
		expencesEntity.setComment(expencesAddRequest.getComment());
		expencesEntity.setDate(expencesAddRequest.getDate());

		expencesRepository.save(expencesEntity);

		ExpencesAddResponce expencesAddResponce = new ExpencesAddResponce();

		expencesAddResponce.setCategory(expencesAddRequest.getCategory());
		expencesAddResponce.setAmount(expencesAddRequest.getAmount());
		expencesAddResponce.setComment(expencesAddRequest.getComment());
		expencesAddResponce.setDate(expencesAddRequest.getDate());

		return expencesAddResponce;
	}

//	=============================== FETCH CALL ==============================

	public List<ExpencesAddResponce> fetchData() {
		List<ExpencesEntity> expencesEntityList = expencesRepository.findAll();

		List<ExpencesAddResponce> expencesResponseList = new ArrayList<>();

		for (ExpencesEntity entity : expencesEntityList) {
			ExpencesAddResponce response = new ExpencesAddResponce();
			response.setCategory(entity.getCategory());
			response.setAmount(entity.getAmount());
			response.setComment(entity.getComment());
			response.setDate(entity.getDate());
			expencesResponseList.add(response);
		}

		return expencesResponseList;
	}
	
	
// ================================	DELETE ==================================

	public String delete(int id) {
		
		expencesRepository.deleteById(id);
		
		return "data deleted !!!";
	}
	
//	========================== UPDATE ====================================

	public ExpencesAddResponce updateData(int id, ExpencesAddRequest expencesAddRequest) {
		
		
		Optional<ExpencesEntity> entityget = expencesRepository.findById(id);
		
		ExpencesEntity expencesEntity = entityget.get();
		
		expencesEntity.setCategory(expencesAddRequest.getCategory());
		expencesEntity.setAmount(expencesAddRequest.getAmount());
		expencesEntity.setComment(expencesAddRequest.getComment());
		expencesEntity.setDate(expencesAddRequest.getDate());
		
		expencesRepository.save(expencesEntity);
		
		ExpencesAddResponce expencesAddResponce = new ExpencesAddResponce();
		
		expencesAddResponce.setCategory(expencesAddRequest.getCategory());
		expencesAddResponce.setAmount(expencesAddRequest.getAmount());
		expencesAddResponce.setComment(expencesAddRequest.getComment());
		expencesAddResponce.setDate(expencesAddRequest.getDate());
		
		return expencesAddResponce;
	}


}
