package com.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.main.beans.LoginPageRequest;
import com.main.beans.LoginPageResponse;
import com.main.entity.LoginPageEntity;
import com.main.exception.LoginPageException;
import com.main.repository.LoginPageRepository;

@Service
public class LoginPageService {

	@Autowired
	private LoginPageRepository loginPageRepository;

//	@Autowired
//	private LoginPageException loginPageException;

//-------------------------------- POST CALL SERVICE --------------------------------

	public LoginPageResponse EnterLoginDetails(LoginPageRequest loginPageRequest) {
		LoginPageEntity loginPageEntity = new LoginPageEntity();
		loginPageEntity.setName(loginPageRequest.getName());
		loginPageEntity.setEmail(loginPageRequest.getEmail());
		loginPageEntity.setPassword(loginPageRequest.getPassword());
		try {
			loginPageRepository.save(loginPageEntity);
		} catch (Exception e) {
			throw new LoginPageException(HttpStatus.INTERNAL_SERVER_ERROR, "data not found");
		}
		LoginPageResponse loginPageResponse = new LoginPageResponse();
		loginPageResponse.setName(loginPageRequest.getName());
		loginPageResponse.setEmail(loginPageRequest.getEmail());
		return loginPageResponse;
	}

// -------------------------------- GET ALL CALL SERVICE --------------------------------

	public List<LoginPageResponse> fetchDetails() {

		List<LoginPageEntity> loginPageEntity = loginPageRepository.findAll();

		List<LoginPageResponse> loginPageResponsesList = new ArrayList<>();

		for (LoginPageEntity login : loginPageEntity) {

			LoginPageResponse loginPageResponse = new LoginPageResponse();

			loginPageResponse.setName(login.getName());
			loginPageResponse.setEmail(login.getEmail());

			loginPageResponsesList.add(loginPageResponse);

		}

		return loginPageResponsesList;
	}

// -------------------------------- GET CALL ID SERVICE --------------------------------

//	public LoginPageResponse fetchDetailByID(int id) {
//
//		Optional<LoginPageEntity> loginPageEntityGet = loginPageRepository.findById(id);
//
//		LoginPageEntity loginPageEntity = loginPageEntityGet.get();
//
//		LoginPageResponse loginPageResponse = new LoginPageResponse();
//
//		loginPageResponse.setName(loginPageEntity.getName());
//		loginPageResponse.setEmail(loginPageEntity.getEmail());
//
//		return loginPageResponse;
//	}

// -------------------------------------- DELETE CALL -----------------------------------

	public String deleteDetails(int id) {

		loginPageRepository.deleteById(id);

		return "details deleted from repo !!!";
	}

// ------------------------------------- UPDATE CALL ------------------------------------

	public LoginPageResponse updateDetails(LoginPageRequest loginPageRequest, int id) {

		Optional<LoginPageEntity> loginPageEntityGet = loginPageRepository.findById(id);

		LoginPageEntity loginPageEntity = loginPageEntityGet.get();

		LoginPageResponse loginPageResponse = new LoginPageResponse();

		loginPageEntity.setName(loginPageRequest.getName());
		loginPageEntity.setEmail(loginPageRequest.getEmail());

		loginPageRepository.save(loginPageEntity);

		loginPageResponse.setName(loginPageRequest.getName());
		loginPageResponse.setEmail(loginPageRequest.getEmail());

		return loginPageResponse;
	}

// ========================= login page access ==================================

	public void loginAccess(LoginPageRequest loginPageRequest) {

		LoginPageEntity entity = loginPageRepository.findByEmail(loginPageRequest.getEmail());
		LoginPageEntity entity2 = loginPageRepository.findByPassword(loginPageRequest.getPassword());

		if (entity.getEmail() == loginPageRequest.getEmail() && entity2.getPassword()==loginPageRequest.getPassword()) {
			String message = "Login Successfuly";

		} else {
			String message = "user not present";
		}

	}
}
