package com.main.beans;

public class LoginPageResponse {

	private String name;

	private String email;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LoginPageResponse(String name, String email) {
		super();
		this.name = name;
		this.email = email;
	}

	public LoginPageResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "LoginPageResponse [name=" + name + ", email=" + email + "]";
	}
	
	
}
