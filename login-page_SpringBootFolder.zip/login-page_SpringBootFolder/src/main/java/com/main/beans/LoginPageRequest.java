package com.main.beans;

import org.hibernate.annotations.processing.Pattern;

public class LoginPageRequest {

	
	private String name;

	private String password;

	private String email;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LoginPageRequest(String name, String password, String email) {
		super();
		this.name = name;
		this.password = password;
		this.email = email;
	}

	public LoginPageRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "LoginPageRequest [name=" + name + ", password=" + password + ", email=" + email + "]";
	}
	
	

}
