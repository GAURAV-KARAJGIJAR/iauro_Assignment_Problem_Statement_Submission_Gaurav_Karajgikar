package com.main.beans;

public class ExpencesAddResponce {

	private String category;
	
    private Double amount;
    
    private String comment;
    
    private String date;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "ExpencesAddResponce [category=" + category + ", amount=" + amount + ", comment=" + comment + ", date="
				+ date + "]";
	}

	public ExpencesAddResponce(String category, Double amount, String comment, String date) {
		super();
		this.category = category;
		this.amount = amount;
		this.comment = comment;
		this.date = date;
	}

	public ExpencesAddResponce() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
	
}
