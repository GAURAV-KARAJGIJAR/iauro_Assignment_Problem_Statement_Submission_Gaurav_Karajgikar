package com.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.main.entity.LoginPageEntity;

@Repository
public interface LoginPageRepository extends JpaRepository<LoginPageEntity, Integer> {

	LoginPageEntity findByEmail(String email);

	LoginPageEntity findByPassword(String password);


}
