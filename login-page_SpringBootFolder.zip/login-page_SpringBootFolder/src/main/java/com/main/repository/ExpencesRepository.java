package com.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.main.ExpencesEntity.ExpencesEntity;

public interface ExpencesRepository extends JpaRepository<ExpencesEntity, Integer> {

}
