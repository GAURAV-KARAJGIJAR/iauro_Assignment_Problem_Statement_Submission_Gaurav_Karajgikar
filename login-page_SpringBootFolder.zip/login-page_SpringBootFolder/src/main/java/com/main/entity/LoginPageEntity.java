package com.main.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Entity")
public class LoginPageEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int ID;
	
	@Column(name="name")
	private String name;
	
	@Column(name="e-mailID")
	private String email;
	
	@Column(name="password")
	private String password;

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LoginPageEntity(int iD, String name, String email, String password) {
		super();
		ID = iD;
		this.name = name;
		this.email = email;
		this.password = password;
	}

	public LoginPageEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "LoginPageEntity [ID=" + ID + ", name=" + name + ", email=" + email + ", password=" + password + "]";
	}
	
	

}
